package ObserverPatternDemo;

public interface IObserver {
	void update(Student student);
}
