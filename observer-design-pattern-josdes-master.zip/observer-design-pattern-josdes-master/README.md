# observer-design-pattern
Observer design pattern example
